The web static components.
